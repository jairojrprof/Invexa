# Invexa — Deploy no Vercel

## Passo 1 — GitHub
1. Acesse https://github.com e crie uma conta (se não tiver)
2. Clique em "New repository"
3. Nome: `invexa`
4. Deixe como Public
5. Clique em "Create repository"
6. Na próxima tela, clique em "uploading an existing file"
7. Arraste o arquivo `index.html` para a área de upload
8. Clique em "Commit changes"

## Passo 2 — Vercel
1. Acesse https://vercel.com
2. Clique em "Sign up" → entre com sua conta GitHub
3. Clique em "Add New Project"
4. Selecione o repositório `invexa`
5. Clique em "Deploy"
6. Aguarde ~1 minuto
7. Pronto! Você vai receber um link tipo: https://invexa.vercel.app

## Passo 3 — Criar seus primeiros convites
No Supabase → SQL Editor, rode:

```sql
-- Primeiro descubra seu user_id após criar sua conta no app:
select id, email from auth.users;

-- Depois crie os convites substituindo <seu-user-id>:
insert into public.convites (codigo, criado_por) values 
  ('JAIRO2026', '<seu-user-id>'),
  ('AMIGO001', '<seu-user-id>'),
  ('AMIGO002', '<seu-user-id>'),
  ('AMIGO003', '<seu-user-id>');
```

## Passo 4 — Configurar email no Supabase
1. Supabase → Authentication → Email Templates
2. Personalize o email de confirmação com o nome "Invexa"
3. Em Authentication → URL Configuration, adicione seu domínio Vercel

## Fluxo do usuário
1. Acessa o link do Vercel
2. Clica em "Criar com convite"
3. Preenche email, senha e código de convite
4. Confirma o email
5. Faz login e cadastra a própria carteira
